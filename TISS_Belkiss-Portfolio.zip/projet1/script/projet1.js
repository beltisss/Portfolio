

//MODAL POUR LA SECTION PROJET 
// Sélectionner tous les éléments qui ouvrent un modal (les éléments avec la classe 'project')
const openModalElements = document.querySelectorAll('.project');

// Sélectionner la croix de fermeture du modal
const closeModalButtons = document.querySelectorAll('.close-modal');

// Sélectionner tous les modals
const modals = document.querySelectorAll('.modal');

// Fonction pour ouvrir un modal lorsque l'élément avec la classe 'project' est cliqué
openModalElements.forEach(element => {
    element.addEventListener('click', () => {
        const modalId = element.getAttribute('data-modal');  // Récupère l'ID du modal à ouvrir
        const modal = document.getElementById(modalId);     // Sélectionne le modal par son ID
        modal.style.display = 'flex';  // Affiche le modal avec un affichage de type flex
    });
});

// Fonction pour fermer le modal quand on clique sur la croix de fermeture
closeModalButtons.forEach(button => {
    button.addEventListener('click', () => {
        const modal = button.closest('.modal');  // Trouve le modal le plus proche du bouton
        modal.style.display = 'none';  // Cache le modal en modifiant son style
    });
});

// Fonction pour fermer le modal quand on clique en dehors de celui-ci
window.addEventListener('click', (e) => {
    modals.forEach(modal => {
        if (e.target === modal) {  // Si le clic est effectué en dehors du modal
            modal.style.display = 'none';  // Cache le modal
        }
    });
});





//ENVOIE DU FORMULAIRE : stockage dans un objet 
// Fonction de gestion de l'envoi du formulaire de contact
document.getElementById("contact-form").addEventListener("submit", function(event) {
    event.preventDefault();  // Empêche le comportement par défaut du formulaire (rechargement de la page)

    // Création de l'objet pour stocker les informations du formulaire
    const formData = {
        civilite: document.getElementById("civilite").value,
        nom: document.getElementById("nom").value,
        prenom: document.getElementById("prenom").value,
        email: document.getElementById("email").value,
        message: document.getElementById("message").value
    };

    // Vérification que tous les champs obligatoires sont remplis
    if (!formData.civilite || !formData.nom || !formData.prenom || !formData.email || !formData.message) {
        alert("Tous les champs doivent être remplis.");
        return;
    }

    // Vérification du format de l'email
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if (!emailPattern.test(formData.email)) {
        alert("Veuillez entrer un email valide.");
        return;
    }

    // Transformation du nom et prénom
    const nomTransforme = formData.nom.toUpperCase();  // Le nom en majuscules
    const prenomTransforme = formData.prenom.charAt(0).toUpperCase() + formData.prenom.slice(1).toLowerCase();  // Première lettre du prénom en majuscule, le reste en minuscule

    // Construction et affichage du message de confirmation
    const confirmationMessage = `Merci ${formData.civilite} ${nomTransforme} ${prenomTransforme}, 
    nous avons bien reçu votre message : "${formData.message}". Nous vous contacterons à l'adresse ${formData.email} dès que possible.`;
    alert(confirmationMessage);

    // Réinitialisation du formulaire après l'envoi
    this.reset();
});




//MODE SOMBRE 
// Fonction pour activer/désactiver le mode sombre (Dark Mode)
const darkModeIcon = document.getElementById('dark-mode-icon');
const body = document.body;

darkModeIcon.addEventListener('click', () => {
    body.classList.toggle('dark-mode');  // Ajoute ou retire la classe 'dark-mode' au body pour activer/désactiver le mode sombre
    
    // Changer l'icône en fonction du mode
    if (body.classList.contains('dark-mode')) {
        darkModeIcon.classList.remove('fa-sun');
        darkModeIcon.classList.add('fa-moon');
    } else {
        darkModeIcon.classList.remove('fa-moon');
        darkModeIcon.classList.add('fa-sun');
    }
});



//MENU HAMBURGER 
// Fonction pour ouvrir/fermer le menu (en mode mobile)
function toggleMenu() {
    const menu = document.querySelector('.navigation');
    const body = document.body;
    
    // Bascule la classe 'active' sur la navigation pour l'afficher/cacher
    menu.classList.toggle('active');
    
    // Applique un flou à l'arrière-plan
    body.classList.toggle('menu-open');
}

// Fonction pour fermer le menu lorsque l'on clique sur un lien du menu
function closeMenu() {
    const menu = document.querySelector('.navigation');
    const body = document.body;

    // Retire la classe 'active' du menu pour le fermer
    menu.classList.remove('active');
    
    // Retire le flou de l'arrière-plan
    body.classList.remove('menu-open');
}


//FAIRE GLISSER L'ECRAN DANS LA SECTION PROJETS 
// Fonction pour implémenter un défilement horizontal dans la section des projets avec la souris
document.addEventListener('DOMContentLoaded', function () {
    const projetsWrapper = document.querySelector('.projets-wrapper');
    let isDown = false;
    let startX;
    let scrollLeft;

    projetsWrapper.addEventListener('mousedown', (e) => {
        isDown = true;
        projetsWrapper.classList.add('active');
        startX = e.pageX - projetsWrapper.offsetLeft;
        scrollLeft = projetsWrapper.scrollLeft;
    });

    projetsWrapper.addEventListener('mouseleave', () => {
        isDown = false;
        projetsWrapper.classList.remove('active');
    });

    projetsWrapper.addEventListener('mouseup', () => {
        isDown = false;
        projetsWrapper.classList.remove('active');
    });

    projetsWrapper.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - projetsWrapper.offsetLeft;
        const walk = (x - startX) * 2;  // 2x vitesse de défilement
        projetsWrapper.scrollLeft = scrollLeft - walk;
    });

    // Gestion du swipe pour les écrans tactiles (mobiles)
    let touchStartX = 0;
    projetsWrapper.addEventListener('touchstart', (e) => {
        touchStartX = e.touches[0].pageX;
    });

    projetsWrapper.addEventListener('touchmove', (e) => {
        if (touchStartX === 0) return;
        const diffX = e.touches[0].pageX - touchStartX;
        projetsWrapper.scrollLeft -= diffX;  // Défilement horizontal
        touchStartX = e.touches[0].pageX;
    });
});


//TOOLTIPS POUR LA SECTION COMPÉTENCES 
// Fonction pour afficher les tooltips au survol des compétences
document.querySelectorAll('.competence').forEach((competence) => {
    competence.addEventListener('mouseover', () => {
        let tooltip = competence.querySelector('.tooltip');
        tooltip.style.visibility = 'visible';  // Affiche le tooltip
        tooltip.style.opacity = '1';
    });

    competence.addEventListener('mouseout', () => {
        let tooltip = competence.querySelector('.tooltip');
        tooltip.style.visibility = 'hidden';  // Cache le tooltip
        tooltip.style.opacity = '0';
    });
});


//MODAL DES HOBBIES 
// Fonction pour afficher un modal avec la description d'un hobby
document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('hobby-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalDescription = document.getElementById('modal-description');
    const closeModal = document.querySelector('.close-modal');

    // Dictionnaire des descriptions des hobbies
    const hobbyDescriptions = {
        cyclisme: {
            title: "Cyclisme",
            description: "Le cyclisme est une activité qui allie sport et aventure. Il permet de découvrir de magnifiques paysages tout en restant actif."
        },
        equitation: {
            title: "Équitation",
            description: "L'équitation est une passion pour les chevaux et la nature. Elle procure une grande sérénité et renforce la connexion avec l'animal."
        },
        peinture: {
            title: "Peinture",
            description: "La peinture est une forme d'expression artistique qui libère l'imagination et immortalise des moments sur toile."
        }
    };

    // Ouvrir le modal pour afficher les détails du hobby
    document.querySelectorAll('.hobby').forEach(hobby => {
        hobby.addEventListener('click', () => {
            const hobbyKey = hobby.getAttribute('data-hobby');
            const hobbyInfo = hobbyDescriptions[hobbyKey];
            modalTitle.textContent = hobbyInfo.title;
            modalDescription.textContent = hobbyInfo.description;
            modal.style.display = 'block';
        });
    });

    // Fermer le modal
    closeModal.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    // Fermer le modal si l'on clique en dehors du modal
    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Gestion du swipe pour les écrans mobiles (carousel des hobbies)
    const carousel = document.querySelector('.carousel');
    let startX;

    carousel.addEventListener('touchstart', (event) => {
        startX = event.touches[0].pageX;
    });

    carousel.addEventListener('touchmove', (event) => {
        const touch = event.touches[0];
        const swipeDistance = touch.pageX - startX;

        if (swipeDistance < -50) {

            carousel.scrollBy({ left: -300, behavior: 'smooth' });
        }
    });
});


